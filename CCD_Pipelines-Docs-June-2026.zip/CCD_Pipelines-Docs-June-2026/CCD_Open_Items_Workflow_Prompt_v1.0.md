# CCD Platform — Open Items Workflow
## Master Remediation Session Prompt
**Date:** 2026-06-08  
**Author:** M. J. Martin, Lead Director Information Security, CVS Health  
**Working directory:** `~/Documents/IP_Lookup/` on macOS (Yggdrasil, user mj0u812)

---

Paste this at the start of a new chat session. Upload the files listed under each workstream before starting that workstream. Do **not** mix workstreams in a single session — complete one, verify the cross-check gate, then move to the next.

---

## Context

Eight workstreams have been identified across the CCD Platform pipeline documentation review (June 2026). They are sequentially dependent — WS-1 must complete before any other workstream touches IPAM data; WS-2 must complete before WS-3 and WS-4; WS-5 through WS-8 are independent and can be sequenced in any order after WS-1.

**Dependency graph:**

```
WS-1 (IPAM r10 import)
  └── WS-2 (LM v5.19 normalization)
        ├── WS-3 (IPAM LOCATION_TYPE sync)
        │     └── WS-4 (Network Groups rebuild)
        └── WS-4 (after WS-3)

WS-5 (Logic Objects — independent, but needs WS-1 first)
WS-6 (EHM null acronym — independent)
WS-7 (Zscaler topology map — fully independent)
WS-8 (Data quality backlog — independent items, parallel)
```

**Hard gates (non-negotiable):**
- `--dry-run` before every write
- `--cross-check` after every import — 0 HIGH required to proceed
- On HIGH violation: `ipam-db.py --restore` immediately
- Update order: LM → IPAM → NDM → EHM → Infra → Platform → ASI
- Complete files only — no patches or sed commands

---

## WS-1 — IPAM r10 Import ★ BLOCKER ★
**Priority:** HIGH — blocks ALL downstream pipelines  
**Status:** Patch CSV produced by `apply_ipam_location_patch.py v1.1.0`. Import pending.  
**Blocks:** CSNA pipeline, canonical objects rebuild, network groups rebuild, Zscaler pipeline

### What was done
`apply_ipam_location_patch.py v1.1.0` was run against `all_IP_networks_v20260603r9.csv` using the Phase 1 remediation patch. The v1.1.0 fix ensures quarantine rows preserve `CANONICAL_LOCATION`/`SITE_CODE`/`ROUTING_DOMAIN`/`HERITAGE` — only `SOURCE=QUARANTINE_v1` and `DATA_QUALITY=Inferred` are stamped. NDM_CONNECTED and SIBLING_CONSENSUS rows receive full location overwrites.

### Session task
```
1. python3 ipam-db.py --dry-run --import ipam-db/all_IP_networks_v20260603r10.csv
   → Review diff: inspect NDM/SIBLING changes, confirm QUARANTINE rows have locations
   
2. python3 ipam-db.py --import ipam-db/all_IP_networks_v20260603r10.csv --type all_IP_networks
   → Verify: "Imported: all_IP_networks_v20260603r10.csv"

3. python3 ipam-db.py --cross-check
   → GATE: 0 HIGH required to proceed
   → Expected MEDIUM: CX13 NET-TYPE-SC-MISMATCH (~3,801 — legacy data, not blocking)

4. python3 ipam-db.py --checksums
   → Verify SHA-256 stored for r10
```

### Success criteria
- `ipam-db.py --cross-check` returns 0 HIGH
- `ipam-db.py --list` shows `all_IP_networks_v20260603r10.csv` as registered
- No QUARANTINE row has `CANONICAL_LOCATION` containing "Unknown"

### Files to upload
| File | Location |
|------|----------|
| `all_IP_networks_v20260603r10.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `ipam-db.py` | `~/Documents/IP_Lookup/` |
| `Must-Read-CCD-Skills_arch.zip` | session prep |

---

## WS-2 — LM v5.19 Normalization
**Priority:** MEDIUM — gates WS-3, WS-4  
**Status:** Issues identified, not yet actioned  
**Session prompt:** `NEXT_SESSION_LM_REMEDIATION_v20260601.md` (upload for detailed context)

### What needs fixing (all in one LM pass → v5.19)

**A. Raw type code normalization (~70 rows in LM `LOCATION_TYPE`):**

| Raw code | Rows | Canonical value |
|----------|------|-----------------|
| CI | 7 | COLO |
| CO | 10 | Corporate |
| IS | 9 | Cloud |
| TP | 20 | Partner |
| MO | 7 | Mail-Order |
| RT | 10 | Retail |
| SP | ~106 | Specialty (21) / Omnicare (78) / Coram (7) — split by FACILITY_OWNER |
| HP / CP | 36+3 | CarePlus |
| NH | 1 | NAAS-Hub |

**B. NET_TYPE de-branding in LM (~39 rows):**
- `CVS-DC` → `DataCenter`
- `AETNA-DC` → `DataCenter`
- `CVS-CallCenter` → `Call-Center`
- `AETNA-CallCenter` → `Call-Center`

**C. Blank NET_TYPE backfill (~2,020 rows):**
- Where blank, derive from `LOCATION_TYPE` (DataCenter→DataCenter, Retail→Retail, etc.)

**D. Specific site fixes:**
- WSL/WSM retail `SITE_CODE` conflict with Aetna RBO hostnames — investigate and assign unique codes
- 3 Omnicare sites currently under NG-SPECIALTY: fix `LOCATION_TYPE` to `Omnicare`
  - Jefferson LA, Las Vegas NV, Tampa FL
- 2 Distribution sites under NG-MAIL-ORDER: fix `LOCATION_TYPE` to `Mail-Order`
  - Loudon TN, Waverly Chemung NY
- Linthicum MD CarePlus site: fix `ROUTING_DOMAIN` or `LOCATION_TYPE` (Azure ExpressRoute mismatch)
- BDL/UND CarePlus VDC city codes: identify and map to correct `CANONICAL_LOCATION`
- Blank `CANONICAL_NAME` rows causing empty-segment nodes in NG-COLO / NG-DATACENTER: populate

**E. SP suffix disambiguation:**
- SP suffix maps to Specialty (21), Omnicare (78), Coram (7) — cannot distinguish from suffix alone
- Apply Option B (immediate): document in LM notes that BU must be read from `LOCATION_TYPE`/`FACILITY_OWNER`, never re-derived from `_SP` suffix
- Document Option A (future): introduce `_OM` for Omnicare, `_CR` for Coram in next LM SITE_CODE revision

### Session task
```
1. Read location_master_SKILL.md before writing any code
2. Load location_master_v5.18.csv
3. Build normalization script or use ipam-db.py --fix-interactive for each category
4. Apply in order: A → B → C → D → E documentation
5. Output: location_master_v5.19.csv

6. python3 preflight_lm_check.py --lm ipam-db/location_master_v5.19.csv
   → GATE: PASS required

7. python3 ipam-db.py --dry-run --import ipam-db/location_master_v5.19.csv --type location_master
8. python3 ipam-db.py --import ipam-db/location_master_v5.19.csv --type location_master
9. python3 ipam-db.py --cross-check
   → GATE: 0 HIGH
```

### Success criteria
- `preflight_lm_check.py --lm location_master_v5.19.csv` → PASS
- No rows with raw type codes (CI/CO/IS/TP/MO/RT/HP/CP/NH) in `LOCATION_TYPE`
- All 20 critical anchors present
- 0 HIGH cross-check violations after import

### Files to upload
| File | Location |
|------|----------|
| `location_master_v5.18.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `location_master_table.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `location_master_SKILL.md` | from `Must-Read-CCD-Skills_arch.zip` |
| `ccd-platform-data-model-SKILL.md` | from `Must-Read-CCD-Skills_arch.zip` |
| `NEXT_SESSION_LM_REMEDIATION_v20260601.md` | from prior session |
| `ipam-db.py` | `~/Documents/IP_Lookup/` |
| `preflight_lm_check.py` | `~/Documents/IP_Lookup/` |

---

## WS-3 — IPAM LOCATION_TYPE Sync from LM
**Priority:** MEDIUM — needs WS-2 complete  
**Status:** Root cause confirmed; fix not yet implemented

### Problem
`all_IP_networks.LOCATION_TYPE` is a denormalized copy that has drifted from the authoritative `LOCATION_TYPE` in `location_master`. **10,567 subnet rows** are affected. The field is currently authored independently in IPAM instead of being derived from the LM join at import time.

### Session tasks

**Task A — One-time patch (all_IP_networks r10 → r11):**
```
# Patch LOCATION_TYPE in IPAM from LM join by SITE_CODE
python3 enrich_ipam_sitecode.py --dry-run   # inspect diff
python3 enrich_ipam_sitecode.py             # write v_r11

python3 ipam-db.py --import ipam-db/all_IP_networks_v20260603r11.csv
python3 ipam-db.py --cross-check   # 0 HIGH gate
```
Note: `enrich_ipam_sitecode.py` was written for the v3.73→v3.74 SITE_CODE migration but its pattern (LM CANONICAL_NAME → SITE_CODE lookup) applies here. A new script may need to be written for the LT sync specifically.

**Task B — `update_ipam.py` ongoing fix:**
Add a pipeline step in `update_ipam.py` that overwrites `all_IP_networks.LOCATION_TYPE` from `location_master` on every update (join on `SITE_CODE`). This prevents the drift from recurring.

**Task C — New cross-check rule `CX-LT-DRIFT`:**
Add to `ipam-db.py`: fires `HIGH` if any IPAM row's `LOCATION_TYPE` differs from its LM `SITE_CODE` entry. Blocks imports where the drift would persist.

### Success criteria
- 0 rows in `all_IP_networks` where `LOCATION_TYPE` differs from LM entry for that `SITE_CODE`
- `update_ipam.py` has LT-sync step (test with --dry-run)
- `ipam-db.py --cross-check` includes CX-LT-DRIFT (0 violations)

### Files to upload
| File | Location |
|------|----------|
| `all_IP_networks_v20260603r10.csv` | `~/Documents/IP_Lookup/ipam-db/` (WS-1 output) |
| `location_master_v5.19.csv` | `~/Documents/IP_Lookup/ipam-db/` (WS-2 output) |
| `location_master_table.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `enrich_ipam_sitecode.py` | `~/Documents/IP_Lookup/` |
| `update_ipam.py` | `~/Documents/IP_Lookup/` |
| `ipam-db.py` | `~/Documents/IP_Lookup/` |
| `ccd-platform-data-model-SKILL.md` | from `Must-Read-CCD-Skills_arch.zip` |

---

## WS-4 — Network Groups Rebuild
**Priority:** MEDIUM — needs WS-2 + WS-3 complete  
**Status:** network_object_catalog_v20260605 has known data issues; requires post-LM/IPAM rebuild

### What changes after WS-2 + WS-3
- LM type code normalization fixes NG-COLO and NG-DATACENTER empty-segment nodes
- 3 Omnicare sites move to NG-OMNICARE
- 2 Distribution sites move to NG-MAIL-ORDER
- Linthicum MD CarePlus site resolves to correct tier
- LOCATION_TYPE sync eliminates 10,567 IPAM rows with wrong zone classification

### Session task
```
# Verify 5 retail stores that appear as direct NG-RETAIL children
# Check if their subnets are in all_IP_networks (wrong) vs retail_networks (correct)
python3 iplookup.sh --ng NG-RETAIL   # identify direct /26 children at Tier-2 level
python3 iplookup.sh <each_cidr>      # confirm routing domain

# If subnets are in all_IP_networks, move to retail_networks pipeline
# (separate retail_networks workstream — document separately)

# Rebuild network groups
python3 build_fw_snat_pools.py
python3 build_internet_segments.py
python3 build_network_groups.py
python3 ipam-db.py --import network-groups/network_object_catalog_vNEW.csv --type network_object_catalog
python3 build_ng_report.py --catalog network-groups/network_object_catalog_vNEW.csv

# Verify reconciliation report is clean
# ng_reconciliation.csv should be 0 rows (no SITE_CODE/LOCATION_TYPE disagreements)
```

### Success criteria
- `ng_reconciliation.csv` returns 0 rows
- NG-COLO and NG-DATACENTER have no empty-segment nodes
- 3 Omnicare sites appear under NG-OMNICARE (not NG-SPECIALTY)
- 2 Distribution sites appear under NG-MAIL-ORDER
- `build_ng_report.py` produces clean HTML with no broken Tier-2 nodes

### Files to upload
| File | Location |
|------|----------|
| `all_IP_networks_v20260603r11.csv` | `~/Documents/IP_Lookup/ipam-db/` (WS-3 output) |
| `location_master_v5.19.csv` | `~/Documents/IP_Lookup/ipam-db/` (WS-2 output) |
| `retail_networks_v2.9.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `build_network_groups.py` | `~/Documents/IP_Lookup/` |
| `build_ng_report.py` | `~/Documents/IP_Lookup/` |
| `build_internet_segments.py` | `~/Documents/IP_Lookup/` |
| `build_fw_snat_pools.py` | `~/Documents/IP_Lookup/` |
| `retail_region_assignment.csv` | `~/Documents/IP_Lookup/` |
| `ccd-platform-data-model-SKILL.md` | from `Must-Read-CCD-Skills_arch.zip` |

---

## WS-5 — Logic Objects + Architecture Model Registry
**Priority:** MEDIUM — independent after WS-1  
**Status:** Design finalized 2026-05-28; session prompt ready  
**Full session prompt:** `NEXT_SESSION_LOGIC_OBJECTS_v20260601.md` — use that as the primary prompt

### Summary of what gets built
- `logic_model_registry.yaml` — Logic Object definitions (members are other canonical objects, not IPs)
- `architecture_model_registry.yaml` — 11 architecture model definitions with detection signals
- `build_canonical_app_objects.py v2.0` — reads both YAML registries; emits LOGIC objects; auto-assigns `APP_ARCHITECTURE`; injects `SERVICE_DEPS` from architecture model requirements
- `generate_canonical_app_objects_explorer.py v2.3.0` — Logic Object display, member drill-through, architecture model panel
- `edit_logic_registry.py` + `edit_arch_registry.py` — interactive YAML editors

### Logic Object families to seed

| Logic Object | Heritage | Members |
|---|---|---|
| AD_LOGIC_CAREMARK | CVS | SVC_AD_CORP_CVSCAREMARK, SVC_AD_CAREMARKRX, SVC_AD_CORP_CVS, SVC_AD_ENT_CVSHEALTH, SVC_AD_DR_CVS |
| AD_LOGIC_CVS_CLINIC | CVS | SVC_AD_MINCLINIC |
| AD_LOGIC_CORAM | CVS | SVC_AD_CORP_OMNICARE, SVC_AD_OMNICARE |
| AD_LOGIC_CVS_SPEC | CVS | SVC_AD_CVTY, SVC_AD_HEALTHEHOST, SVC_AD_PPOM, SVC_AD_PDCHS, SVC_AD_PDCSS, SVC_AD_HEALTHDS, SVC_AD_RESOURCE, SVC_AD_PDC_DMZ |
| AD_LOGIC_HCB | AETNA | SVC_AD_AETH_AETNA, SVC_AD_AETNA, SVC_AD_AHM_CORP, SVC_AD_MERITAIN, SVC_AD_XAUTH_COFINITY |
| AD_LOGIC_ALL | MIXED | wildcard: ALL SVC_AD_* objects |
| VDI_LOGIC_ALL | MIXED | Citrix delivery pools — CVS and HCB |
| K8S_LOGIC_CLUSTER | MIXED | SVC_K8S_MASTERS, SVC_K8S_WORKERS, SVC_K8S_INGRESS, SVC_K8S_EGRESS, SVC_ISTIO, SVC_ENVOY, SVC_CILIUM |
| MONITORING_LOGIC_ALL | MIXED | SVC_SPLUNK, SVC_ITM, SVC_SITESCOPE, SVC_OBM_PROD |
| SECURITY_LOGIC_SCANNERS | MIXED | SVC_QUALYS, SVC_CROWDSTRIKE |
| IDENTITY_LOGIC_ALL | MIXED | AD_LOGIC_ALL + SVC_BEYONDTRUST, SVC_CENTRIFY |

### Architecture models to define
`single-instance`, `2-tier`, `3-tier`, `3-tier-ha` (VIP_COUNT > 0), `3-tier-ha-ft` (VIP_COUNT > 0 AND LOCATION_COUNT > 1), `kubernetes`, `microservice`, `serverless`, `vdi`, `api-gateway`, `mainframe`

### New schema fields (additive only)
- `MEMBER_OBJECTS` — pipe-sep list of member object names (Logic Objects only)
- `LOGIC_OBJECT_OF` — pipe-sep list of Logic Objects this Direct Object belongs to
- `ARCH_MODEL` — architecture model name (traceability field beyond APP_ARCHITECTURE display value)

### Files to upload (see NEXT_SESSION_LOGIC_OBJECTS_v20260601.md §4 for full list)
| File | Location |
|------|----------|
| `canonical_app_objects_vLATEST.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `build_canonical_app_objects.py` | `~/Documents/IP_Lookup/` |
| `generate_canonical_app_objects_explorer.py` | `~/Documents/IP_Lookup/` |
| `ent-ipdataset-CPC-CORE-SERVICES-vLATEST.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `ent-ipdataset-F5-VIP-REGISTRY-v20260520.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `canonical_app_objects_SKILL.md` | from `Must-Read-CCD-Skills_arch.zip` |
| `NEXT_SESSION_LOGIC_OBJECTS_v20260601.md` | prior session output |

---

## WS-6 — EHM Null Acronym Resolution
**Priority:** MEDIUM — independent  
**Status:** 6,282 null-acronym EHM hosts in review queue; 3 sub-populations identified

### Sub-populations

**Sub-population 1: NON_PROD rows (~estimated majority)**
- Condition: `NON_PROD=Y` AND `PRIMARY_ACRONYM` blank
- Action: **Acceptable — no action required.** NON_PROD apps without acronyms are excluded from canonical objects by design. Document as intentional.

**Sub-population 2: Rack servers needing SNOW investigation**
- Condition: `SERVER_CLASS` contains "Rack" or similar physical server class, non-cloud `ROUTING_DOMAIN`
- Action: Create SNOW ticket list for server owners to confirm `APP_ACRONYM`. Export candidate list from review queue CSV for SNOW bulk update.
- Script: filter `canonical_app_objects_review_vDATE.csv` by `SERVER_CLASS`

**Sub-population 3: Azure dev VMs (~hostname pattern)**
- Condition: `SERVER_NAME` matches cloud auto-generated patterns (`ip-N-N-N-N`, `mazq*`, Azure VM name patterns) AND `ROUTING_DOMAIN` = `Cloud-Azure`
- Action: Apply `PRIMARY_ACRONYM` from hostname prefix decoder or ADL enrichment. `ccd_host_enrichment.py::derive_primary_acronym_from_adl()` is the right tool.
- Script: `python3 update_app.py --enrich-only --enrich-file [adl_enrichment_file]`

**Sub-population 4: COLO 201 null-acronym rows**
- Condition: `ROUTING_DOMAIN=COLO`, blank `PRIMARY_ACRONYM`, `SERVER_CLASS` = infrastructure type
- Action: These are INFRA or SERVICE objects misrouted to EHM. Add their `APP_ACRONYMS` tokens to `INFRA_ACRONYM_SET` in `build_canonical_app_objects.py` so they classify as INFRA objects instead of falling into the APP null queue.

### Session task
```
# Step 1: Analyze the review queue
python3 build_canonical_app_objects.py --dry-run   # get fresh null_acronym count

# Step 2: Filter sub-populations from canonical_app_objects_review_vDATE.csv
# Sub-pop 1 (NON_PROD): filter where NON_PROD=Y → count, document, no action
# Sub-pop 2 (rack servers): filter SERVER_CLASS patterns → export SNOW list
# Sub-pop 3 (Azure VMs): filter ROUTING_DOMAIN=Cloud-Azure + hostname patterns → ADL enrichment
# Sub-pop 4 (COLO): filter ROUTING_DOMAIN=COLO → add to INFRA_ACRONYM_SET

# Step 3: Run ADL enrichment for Sub-pop 3
python3 update_app.py --enrich-only   # uses ADL IP-match from ccd_host_enrichment.py

# Step 4: Rebuild canonical objects post-enrichment
python3 build_canonical_app_objects.py --ipam-dir ./ipam-db --out-dir ./processed_outputs
python3 ipam-db.py --import processed_outputs/canonical_app_objects_vNEW.csv --type canonical_app_objects
```

### Success criteria
- Sub-pop 1 (NON_PROD): documented, no action
- Sub-pop 2 (rack servers): SNOW ticket list exported, count documented
- Sub-pop 3 (Azure VMs): ADL enrichment applied, null count reduced
- Sub-pop 4 (COLO): INFRA_ACRONYM_SET additions in `build_canonical_app_objects.py`
- Net null-acronym count reduced from 6,282 (document new baseline)

### Files to upload
| File | Location |
|------|----------|
| `canonical_app_objects_review_vLATEST.csv` | `~/Documents/IP_Lookup/processed_outputs/` |
| `ent_host_master_vLATEST.csv` | `~/Documents/IP_Lookup/ipam-db/` |
| `build_canonical_app_objects.py` | `~/Documents/IP_Lookup/` |
| `update_app.py` | `~/Documents/IP_Lookup/` |
| `ccd_host_enrichment.py` | `~/Documents/IP_Lookup/` |
| Latest ADL report zip | `~/Documents/IP_Lookup/IP_Datasets_Raw/APP_DATA-*/` |

---

## WS-7 — Zscaler Force-Directed Topology Map
**Priority:** LOW — fully independent new build  
**Status:** Session prompt ready; inputs already produced  
**Full session prompt:** `build_zscaler_fw_topology_map_prompt.md` — use that as the primary prompt

### What gets built
A self-contained interactive HTML force-directed topology map showing site-to-firewall relationships from Zscaler egress traffic. Distinct from the existing tabular `Zscaler_Topology_Report.html` — this is a graph visualization.

### Inputs (already produced — just upload)
| File | Notes |
|------|-------|
| `zscaler_topology_vYYYYMMDD.csv` | Output of `build_zscaler_topology.py` |
| `unmatched_source_subnets_v20260608.csv` | Output of `find_unmatched_source_subnets.py` |
| `build_zscaler_fw_topology_map_prompt.md` | Full session prompt with schema details |

### Key design constraints (from session prompt)
- Force-directed graph: nodes = sites (SITE_CODE) + firewall nodes; edges = traffic flows weighted by CONNECTIONS
- SITE_CODE is the critical grouping attribute — two subnets in the same /24 but different SITE_CODEs are different nodes
- Color coding by ROUTING_DOMAIN
- Blind spot nodes (unmatched /24s) rendered distinctly
- Self-contained HTML — no server, no CDN

---

## WS-8 — Data Quality Backlog
**Priority:** LOW — independent items; can be parallelized  
**Status:** Mix of one-time runs and minor fixes

### WS-8a: Qualys Pipeline Refresh
**Issue:** Qualys pipeline stale since EHM r13 (current: r22)  
**Script:** `build_qualys_pipeline.py v1.6`  
**Action:**
```
python3 build_qualys_pipeline.py --ipam-dir ./ipam-db --qualys-dir ./IP_Datasets_Raw/Qualys
python3 ipam-db.py --import <output> --type qualys_data
```
**Files needed:** Latest Qualys VAE Risk Register xlsx from `IP_Datasets_Raw/Qualys/`

---

### WS-8b: placeholder_networks Rebuild
**Issue:** Built against LM v5.9c; current LM is v5.18 → v5.19 (after WS-2)  
**Script:** `build_placeholder_networks.py v1.1.0`  
**Action:** Run after WS-2 completes (needs LM v5.19)
```
python3 build_placeholder_networks.py --ipam-dir ./ipam-db
python3 ipam-db.py --import ipam-db/placeholder_networks_vNEW.csv --type placeholder_networks
python3 ipam-db.py --cross-check   # CX6 violations should drop
```

---

### WS-8c: NET_TYPE Audit
**Issue:** `build_ip_allocation_model.py v1.1.0` not yet run against `all_IP_networks_v20260603r10` (or r11 after WS-3)  
**Run after WS-3 completes** (needs r11)
```
python3 build_ip_allocation_model.py --ipam-dir ./ipam-db
# Produces: ipam_prefix_corrections.csv, ipam_allocation_gaps.csv, ipam_allocation_violations.csv

python3 apply_prefix_corrections.py \
    --corrections processed_outputs/ipam_prefix_corrections_vDATE.csv \
    --ipam-dir ./ipam-db --live

python3 ipam-db.py --import ipam-db/all_IP_networks_vNEXT.csv
python3 ipam-db.py --cross-check   # 0 HIGH gate
```

---

### WS-8d: IBM RxConnect Gurgaon Offshore Object
**Issue:** 107 hosts in Gurgaon India with no PRIMARY_ACRONYM → not represented in canonical objects  
**Action:**
- Confirm subnet CIDR for Gurgaon RxConnect hosts from EHM
- Verify `NET_TYPE=Offshore-Dev` and `ROUTING_DOMAIN=Offshore` in IPAM
- Add `APP_RXCONNECT_OFFSHORE` object: add subnet to `INFRA_ACRONYM_SET` or create manual canonical object row
- Run `classify_net_type.py` if NET_TYPE not yet set

---

### WS-8e: app_reference.csv Coverage Gap Analysis
**Issue:** 2,295 apps in `app_reference.csv` not yet cross-referenced against canonical objects  
**Action:**
```python
# Cross-reference EHM_PRIMARY_COUNT vs canonical MEMBER_COUNT per APM_ID
# Identify: apps with EHM hosts but no canonical object (coverage gap)
# Identify: apps with FW rules but 0 EHM hosts (phantom rules)
# Output: app_coverage_gap_analysis_vDATE.csv
```
This is an analytical workstream — no IPAM changes. Python script or iplookup.sh batch query.

---

### WS-8f: ODID Validation for Stack 4 COLO
**Issue:** ODID (Observation Domain ID) not validated for Stack 4 COLO Flexible NetFlow per-VRF  
**Action:** Add ODID validation check to CSNA pre-flight — verify each COLO subnet has a corresponding ODID in the NetFlow collection configuration. Currently no automated check exists.
- Document expected ODID assignments per COLO VRF (Switch LV, ATL, TRE)
- Add validation step to `build_csna_site_registry.py` or as a standalone check

---

### WS-8g: Stack 1/2 IP Collision Documentation
**Issue:** 45 confirmed IP collisions between Stack 1 (Internal-PBM) and Stack 2 (Internal-HCB) — disambiguation is working (ROUTING_DOMAIN), but collisions are not documented  
**Action:** Export collision list:
```bash
iplookup.sh --routing-domain Internal-PBM --csv > pbm_ips.csv
iplookup.sh --routing-domain Internal-HCB --csv > hcb_ips.csv
# Cross-reference CIDRs — document the 45 collisions in a reference CSV
```

---

### WS-8h: FMC API JSON Export
**Issue:** FMC object resolution currently 50–63% without object definitions export  
**Action:** Export FMC ACP JSON from Cisco FMC management console:
- Navigate to FMC → Policies → Access Control → Export → JSON (*.acp.json)
- Re-run `fw_rule_extraction_translation.py` with `--fmc-json` flag
- Expected: resolution improves to ~95%
- **Prerequisite:** Access to Cisco FMC management console

---

### WS-8i: check_toolset.py Version Update
**Issue:** `check_toolset.py` TESTS list references stale version expectations  
**Action:** Update `TESTS` dict in `check_toolset.py` to match current deployed versions:

| Test | Old expected | Current |
|------|-------------|---------|
| ipam-db.py --version | v3.13 | v3.15.5 |
| update_app version | v1.7 | v1.8 |
| build_canonical_app_objects version | v1.4 | v1.4.3 |
| build_external_ip_registry version | 1. (any) | v1.4.0 |

Small change — update TESTS list in `check_toolset.py`, bump version to v1.1.0.

---

## Quick Reference: Workstream Status Dashboard

| WS | Workstream | Priority | Depends on | Status |
|----|-----------|----------|-----------|--------|
| WS-1 | IPAM r10 import | HIGH ★ BLOCKER | — | Patch ready, import pending |
| WS-2 | LM v5.19 normalization | MEDIUM | WS-1 | Not started |
| WS-3 | IPAM LOCATION_TYPE sync | MEDIUM | WS-2 | Not started |
| WS-4 | Network Groups rebuild | MEDIUM | WS-2, WS-3 | Not started |
| WS-5 | Logic Objects + Arch Model | MEDIUM | WS-1 | Design complete; build ready |
| WS-6 | EHM null acronym resolution | MEDIUM | WS-1 | Sub-populations identified |
| WS-7 | Zscaler topology map | LOW | — | Session prompt ready |
| WS-8a | Qualys pipeline refresh | LOW | — | Stale since r13 |
| WS-8b | placeholder_networks rebuild | LOW | WS-2 | Needs LM v5.19 |
| WS-8c | NET_TYPE audit | LOW | WS-3 | Needs r11 |
| WS-8d | RxConnect Offshore object | LOW | WS-1 | Ready |
| WS-8e | app_reference coverage analysis | LOW | WS-5 (ideal) | Ready |
| WS-8f | ODID COLO validation | LOW | — | Design needed |
| WS-8g | Stack 1/2 collision documentation | LOW | — | Ready |
| WS-8h | FMC API JSON export | LOW | FMC access | Requires console access |
| WS-8i | check_toolset.py update | LOW | — | Small fix; ready |

---

## Session Rules (apply to every session)

```
# From CCD_RULES.md — always in effect
1. --dry-run before every write — non-negotiable
2. --cross-check after every IPAM import — 0 HIGH required
3. On HIGH violation: ipam-db.py --restore immediately
4. Complete files only — never patches or sed commands
5. Update order: LM → IPAM → NDM → EHM → Infra → Platform → ASI
6. NEVER delete or archive location_master files without explicit confirmation + verified backup
7. LM changes cascade — treat as high risk; downstream rebuild required after every LM version change
8. vbare is a hard stop — never use bare filename in production
9. CANONICAL_LOCATION must exist in LM before any subnet or host row is committed
10. Register source files with dsr.py before processing
```
